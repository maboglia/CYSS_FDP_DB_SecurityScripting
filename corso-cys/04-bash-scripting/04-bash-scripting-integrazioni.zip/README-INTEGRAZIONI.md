# Integrazioni al modulo 4 – Bash scripting

Questo archivio contiene **solo i nuovi materiali** da aggiungere al repository esistente:
- sei nuove cartelle in `dispense/` (lezioni 15–20);
- sei nuove cartelle in `codice/` con script e dataset di supporto.

Non sostituisce né replica le cartelle già presenti. Copiare il contenuto di `dispense/` e `codice/` nelle rispettive cartelle del repository.

## Mappa delle integrazioni

| Lezione | Argomento | Script |
|---|---|---|
| 15 | Espressioni regolari | `24-grep-errori.sh`, `25-pattern-ipv4-candidato.sh` |
| 16 | GNU sed e awk | `26-sed-filtra-log.sh`, `27-awk-riepilogo-accessi.sh` |
| 17 | Array e variabili avanzate | `28-array-utenti.sh`, `29-parametri-speciali.sh` |
| 18 | Script interattivi avanzati | `30-menu-select.sh`, `31-parse-opzioni-shift.sh` |
| 19 | Segnali e trap | `32-trap-pulizia.sh` |
| 20 | Espansioni Bash | `33-espansioni-demo.sh`, `34-confronto-process-substitution.sh` |

## Requisiti ed esecuzione
- Bash 4+ consigliato; gli esempi sono pensati per Linux.
- Per `sed`, `grep`, `awk`, `sort` e `diff` sono usati strumenti GNU o comuni nelle distribuzioni Linux.
- Rendere eseguibili gli script, se necessario: `chmod +x codice/*/*.sh`.
- Eseguire gli script da terminale con `bash percorso/script.sh`.

I dati sono sintetici e destinati esclusivamente al laboratorio. Non usare i comandi di esempio per operare su sistemi o log senza autorizzazione.
